singleton Material(gaoaza_gauges_on)
{
    mapTo = "gaoaza_gauges_on";
    diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    specularMap[1] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    normalMap[1] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    specularMap[0] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    normalMap[0] = "vehicles/17silv/TXT/gaoaza_interior.dds";
    diffuseColor[0] = "0 0 0 1";
    specularPower[0] = "32";
    specularPower[1] = "32";
    pixelSpecular[0] = "1";
    useAnisotropic[0] = "1";
    materialTag0 = "beamng"; materialTag1 = "vehicle";
    cubemap = "global_cubemap_metalblurred";
    emissive[1] = "1";
    diffuseColor[1] = "0 0 0 0";
    useAnisotropic[1] = "1";
    translucent = "0";	
};

singleton Material(gaoaza_chrome)
{
    mapTo = "gaoaza_chrome";
    diffuseMap[0] = "vehicles/17silv/gaoaza_chrome.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_black)
{
   mapTo = "gaoaza_black";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_black.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_black.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_black.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_black_s.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_black_plastic)
{
   mapTo = "gaoaza_black_plastic";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_black.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_black.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_black.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_black.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_cloth02_5hbj)
{
   mapTo = "gaoaza_cloth02_5hbj";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_cloth02_5hbj.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_cloth02_5hbj.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_cloth02_5hbj.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_cloth02_5hbj.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_detail2)
{
   mapTo = "gaoaza_detail2";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_detail2.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_detail2.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_detail2.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_detail2.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_dials)
{
   mapTo = "gaoaza_dials";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_dials.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_dials.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_dials.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_dials.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_escalade_12_doortags_diff)
{
   mapTo = "gaoaza_escalade_12_doortags_diff";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_doortags_diff.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_doortags_diff.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_doortags_diff.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_doortags_diff.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_escalade_12_symbols_diff)
{
   mapTo = "gaoaza_escalade_12_symbols_diff";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_diff.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_diff.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_diff.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_diff.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "1";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_escalade_12_symbols_embossed_diff)
{
   mapTo = "gaoaza_escalade_12_symbols_embossed_diff";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_embossed_diff.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_embossed_diff.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_embossed_diff.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_escalade_12_symbols_embossed_diff.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "1";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_gray)
{
   mapTo = "gaoaza_gray";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_gray.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_gray.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_gray.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_gray.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_interior)
{
   mapTo = "gaoaza_interior";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_interior.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_interior.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_interior.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_interior.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_ligth_5hbj)
{
    mapTo = "gaoaza_ligth_5hbj";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_ligth_5hbj.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_maroon)
{
    mapTo = "gaoaza_maroon";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_maroon.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_metal)
{
    mapTo = "gaoaza_metal";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_metal.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_red)
{
    mapTo = "gaoaza_red";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_red.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_silver)
{
    mapTo = "gaoaza_silver";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_silver.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.2";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_plain_gray)
{
   mapTo = "gaoaza_plain_gray";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_plain_gray.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_plain_gray.dds";
   normalMap[0] = "vehicles/17silv/TXT/gaoaza_plain_normal.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_plain_gray.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_plain_gray.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_screen)
{
   mapTo = "gaoaza_screen";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_screen.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_screen.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_screen.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_screen.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_speaker)
{
   mapTo = "gaoaza_speaker";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_speaker.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_speaker.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_speaker.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_speaker.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_symbols_5hbj)
{
   mapTo = "gaoaza_symbols_5hbj";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_symbols_5hbj.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_symbols_5hbj.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_symbols_5hbj.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_symbols_5hbj.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "1";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_white)
{
   mapTo = "gaoaza_white";
   reflectivityMap[0] = "vehicles/17silv/TXT/gaoaza_white.dds";
   diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_white.dds";
   normalMap[0] = "vehicles/common/null_n.dds";
   diffuseMap[1] = "vehicles/17silv/TXT/gaoaza_white.dds";
   specularMap[1] = "vehicles/17silv/TXT/gaoaza_white.dds";
   specularPower[0] = "64";
   pixelSpecular[0] = "1";
   specularPower[1] = "64";
   pixelSpecular[1] = "1";
   diffuseColor[0] = "1 1 1 1";
   diffuseColor[1] = "1 1 1 1";
   useAnisotropic[0] = "1";
   useAnisotropic[1] = "1";
   castShadows = "1";
   translucent = "0";
   doubleSided = "1";
   alphaTest = "1";
   alphaRef = "0";
   dynamicCubemap = false; //cubemap = "BNG_Sky_02_cubemap";
   materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_silver)
{
    mapTo = "gaoaza_silver";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_silver.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.2";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};

singleton Material(gaoaza_blackshine)
{
    mapTo = "gaoaza_blackshine";
    diffuseMap[0] = "vehicles/17silv/TXT/gaoaza_black.dds";
    normalMap[0] = "vehicles/common/null_n.dds";
    diffuseColor[0] = "1 1 1 0.1";
    specularPower[0] = "24";
    useAnisotropic[0] = "1";
    castShadows = "1";
    translucent = "0";
    translucentBlendOp = "None";
    alphaTest = "0";
    alphaRef = "0";
    dynamicCubemap = true;
    doubleSided = "1";	
    materialTag0 = "beamng"; materialTag1 = "vehicle";
};